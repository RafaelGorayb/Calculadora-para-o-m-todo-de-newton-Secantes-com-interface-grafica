package calculadorapedrao;

import static calculadorapedrao.telaPrincipal.jTextArea1;
import static calculadorapedrao.telaPrincipal.precisaoString;
import static calculadorapedrao.telaPrincipal.x0String;
import static calculadorapedrao.telaPrincipal.x1String;
import static java.lang.StrictMath.abs;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author rafael
 */
public class calculos {

    public static float f(float x) {

        float func;
        //func = Float.parseFloat(telaPrincipal.equacao.getText());
        func = x*x*x + 10*x - 28;
        

        return func;
    }

// Definicao da derivada da funcao f(x)
    public static float df(float x) {

        float deriv;
       // deriv = Float.parseFloat(telaPrincipal.equacaoDerivada.getText());
       deriv = 3*x*x + 10;
        return deriv;
    }

    public static void metodoSecante() {

        int i = 0;
        float x0, x1, fx1, fx0, fxn, xn = 0, erro, raiz, prec;
        char c;

        x0 = Float.parseFloat(x0String.getText());
        x1 = Float.parseFloat(x1String.getText());
        prec = Float.parseFloat(precisaoString.getText());;
        erro = 1;

        // Executa o loop enquanto o erro é maior que a precisao
        while (erro >= prec) {

            // Calculo do valor da funcao no ponto encontrado e soma do contador de iteracoes
            i++;

            fx0 = f(x0);
            fx1 = f(x1);
            xn = x1 - ((x1 - x0) / (fx1 - fx0)) * fx1;
            erro = abs(x1 - x0) / abs(x1);
            fxn = f(xn);

            if (erro > prec) {
                c = '>';
            } else {
                c = '<';
            }

            String iS = String.valueOf(i);
            String xnS = String.valueOf(xn);
            String erroS = String.valueOf(erro);
            String cS = String.valueOf(c);
            String precS = String.valueOf(prec);

            jTextArea1.append("iteracao " + iS + "    Valor da raiz: " + xnS + "        erro: " + erroS + "" + c + " " + precS + "\n");

            x0 = x1;
            x1 = xn;
        }

        raiz = xn;
        String raizSS = String.valueOf(raiz);
        jTextArea1.append("\n\n");
        jTextArea1.append("A precisao desejada foi atingida apos " + i + " iteracoes e valor da raiz igual a " + raizSS + "\n");
        
        String equacao = "-";
        String metodo = "Secante";
        String linha[] = {
                equacao,
                metodo,
                x0String.getText(),
                x1String.getText(),
                raizSS
            
            };
        ((DefaultTableModel) telaPrincipal.jTable1.getModel()).addRow(linha);

    }

    public static void metodoNewton() {

        int i = 0;
        /* Contador de iteracoes */
        float x0, xn = 0, erro, raiz, prec;
        char c;

        x0 = Float.parseFloat(x0String.getText());
        prec = Float.parseFloat(precisaoString.getText());;

        erro = 1;

        // Executa o loop enquanto fxn ("erro") > prec
        while (erro > prec) {

            // Incrementa o contador de iteracoes
            i++;

            // Calculo do valor da funcao no ponto encontrado
            xn = x0 - f(x0) / df(x0);
            erro = abs(xn - x0) / abs(xn);

            if (erro > prec) {
                c = '>';
            } else {
                c = '<';
            }

            String iS = String.valueOf(i);
            String xnS = String.valueOf(xn);
            String erroS = String.valueOf(erro);
            String cS = String.valueOf(c);
            String precS = String.valueOf(prec);

            //Imprime o numero da iteracao, o valor da raiz e o erro em relacao a precisao
            jTextArea1.append("iteracao " + iS + "    Valor da raiz: " + xnS + "        erro: " + erroS + "" + c + " " + precS + "\n");

            x0 = xn;
        }

        raiz = xn;
        String raizSN = String.valueOf(raiz);
        jTextArea1.append("\n\n");
        jTextArea1.append("A precisao desejada foi atingida apos " + i + " iteracoes e valor da raiz igual a " + raizSN + "\n");
        
        String equacao = "-";
        String metodo = "Newton";
        String linha[] = {
                equacao,
                metodo,
                x0String.getText(),
                x1String.getText(),
                raizSN
            
            };
        ((DefaultTableModel) telaPrincipal.jTable1.getModel()).addRow(linha);
    }

}
